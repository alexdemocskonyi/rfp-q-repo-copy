var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/embed.js
var embed_exports = {};
__export(embed_exports, {
  default: () => embed_default
});
module.exports = __toCommonJS(embed_exports);
var import_openai = require("openai");
var openai = new import_openai.OpenAI({ apiKey: process.env.OPENAI_API_KEY });
var embed_default = async (req, res) => {
  try {
    const { input, model = "text-embedding-3-small" } = req.body;
    if (!input || typeof input !== "string") {
      return res.status(400).json({ error: "Invalid input" });
    }
    const embeddingResponse = await openai.embeddings.create({ input, model });
    const embedding = embeddingResponse.data[0]?.embedding;
    if (!embedding) {
      throw new Error("No embedding returned.");
    }
    return res.status(200).json({ embedding });
  } catch (err) {
    console.error("\u274C Embed function error:", err);
    return res.status(500).json({ error: err.message || "Unknown error" });
  }
};
